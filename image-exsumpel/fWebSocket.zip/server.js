// server.js - ฝั่ง Server (Backend)
const express = require("express");
const http = require("http");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

// เสิร์ฟไฟล์หน้าเว็บจากโฟลเดอร์ public
app.use(express.static("public"));

// เก็บจำนวนผู้ใช้ที่ออนไลน์ (ตัวอย่างง่ายๆ)
let onlineUsers = 0;

// เมื่อมี client เชื่อมต่อเข้ามาผ่าน WebSocket
io.on("connection", (socket) => {
  onlineUsers++;
  console.log(`ผู้ใช้เชื่อมต่อเข้ามา (id: ${socket.id}) | ออนไลน์ตอนนี้: ${onlineUsers} คน`);

  // แจ้งทุกคนว่ามีคนออนไลน์เพิ่ม
  io.emit("user count", onlineUsers);

  // รับข้อความจาก client คนหนึ่ง แล้วส่งกระจายไปหาทุกคน (broadcast)
  socket.on("chat message", (data) => {
    console.log(`ข้อความจาก ${data.user}: ${data.text}`);

    // ส่งข้อความไปให้ "ทุกคน" ที่เชื่อมต่ออยู่ รวมถึงคนส่งเอง
    io.emit("chat message", {
      user: data.user,
      text: data.text,
      time: new Date().toLocaleTimeString("th-TH"),
    });
  });

  // แสดงสถานะ "กำลังพิมพ์..."
  socket.on("typing", (user) => {
    socket.broadcast.emit("typing", user); // ส่งให้ทุกคน "ยกเว้น" คนที่พิมพ์
  });

  // เมื่อ client ตัดการเชื่อมต่อ (ปิดหน้าเว็บ/หลุดเน็ต)
  socket.on("disconnect", () => {
    onlineUsers--;
    console.log(`ผู้ใช้ออกจากระบบ (id: ${socket.id}) | ออนไลน์ตอนนี้: ${onlineUsers} คน`);
    io.emit("user count", onlineUsers);
  });
});

const PORT = 3000;
server.listen(PORT, () => {
  console.log(`เซิร์ฟเวอร์กำลังทำงานที่ http://localhost:${PORT}`);
});
